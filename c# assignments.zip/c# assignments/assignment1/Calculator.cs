﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sample
{
    class Calculator
    {
        static void Main(string[] args)
        {
            int firstNumber;
            int secondNummber;
            string operation;
            int result;

            Console.WriteLine("Enter FirstNumber: ");
            firstNumber = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter SecondNumber: ");
            secondNummber = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Operation(+,-,*,/): ");
            operation = Console.ReadLine();

            switch (operation)
            {
                case "-":

                    result = firstNumber - secondNummber;
                    Console.WriteLine("your answer is " + firstNumber + operation + secondNummber + " = " + result);
                    break;

                case "*":
                    result = firstNumber * secondNummber;
                    Console.WriteLine("your answer is " + firstNumber + operation + secondNummber + " = " + result);
                    break;

                case "+":
                    result = firstNumber + secondNummber;
                    Console.WriteLine("your answer is " + firstNumber + operation + secondNummber + " = " + result);
                    break;

                case "/":
                    result = firstNumber / secondNummber;
                    Console.WriteLine("your answer is " + firstNumber + operation + secondNummber + " = " + result);
                    break;

                default:
                    System.Console.WriteLine("enter a valid opertor");
                    break;
            }
        }
    }
}